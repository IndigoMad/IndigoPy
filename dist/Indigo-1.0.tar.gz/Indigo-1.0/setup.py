from distutils.core import setup

setup(name='Indigo',
    version='1.0',
    author='Indigo Li',
    author_email='indigomad@pku.edu.cn',
    url='',
    packages=['Indigo','Indigo.GUI','Indigo.Protein'],
)