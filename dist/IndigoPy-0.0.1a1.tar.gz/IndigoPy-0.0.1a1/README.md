# IndigoPy
This package contains some useful tools in many fields including GUI, mathematical functions, plot and protein. I just wrote what i need and I will keep updating it but it might not be well tested.

Modules below is completed:

* **IndigoPy.Protein.pdb**
* **IndigoPy.Math.Funcmaker**

Modules below is uncompleted but you can use it (be cautious, they may be different in a new version):

* **IndigoPy.Math.coordinates**
* **IndigoPy.Math.plot**

Modules below need some modifications before using:
* **IndigoPy.GUI**

